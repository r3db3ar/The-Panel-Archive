Two's Development "Dashactyl Premium" License

Copyright (c) 2021 Two

Permission is hereby granted, to the user ("You" or "User") obtaining a copy
of this software and associated documentation files (the "Software") with permission from the copyright holder, to deal in the Software with restriction. 

The User can use, copy, modify, merge the Software, until the permission is revoked by Two, the copyright holder.

The User have no permission to publish, distribute, sublicense, and/or sell copies fo the Software, unless given permission otherwise.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.