# This repository is now archived and locked. Go to https://github.com/orgs/Dashactyl-Development/repositories for more update-to-date updates.

---

![Banner](https://media.discordapp.net/attachments/706970617471303761/768606122147708968/pterodactyl-panel.png)

# Dashactyl

Dashactyl is a client area, which allows users to split resources throughout multiple servers on the Pterodactyl Panel, and uses a Discord OAuth2 as a login system. 

Dashactyl is developed by the community and people. Check out the Discord: https://discord.gg/yEv2KhVbWX

Website: https://dashactyl.com

# Wiki

Need to install Dashactyl? Need API documentations? Need a place to find themes?

Check out the wiki! https://github.com/real2two/dashactyl/wiki

# Disclaimer

We are not responsible for any damages.

You should not download anything from the develop branch! These files are not ready for production yet, and will be soon!
